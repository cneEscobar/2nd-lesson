public class Loader {
    public static void main(String[] args) {
        int value = 200000;
//        for(int i=0; i<210001; i++){
//            System.out.println("Билет №" + i);
//        }
//
//        int i=0;
//        while(i<210000){
//            i++;
//            System.out.println("Билет №" + i);
//        }
//
        do{
            System.out.println("Билет №" + value);
            value++;
        } while (value != 210001);
    }
}
