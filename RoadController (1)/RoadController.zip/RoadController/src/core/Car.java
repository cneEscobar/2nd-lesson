package core;

public class Car
{
    public String number; //Создание переменной
    public int height; //Создание переменной
    public double weight; //Создание переменной
    public boolean hasVehicle; //Создание переменной
    public boolean isSpecial; //Создание переменной

    public String toString()
    {
        String special = isSpecial ? "СПЕЦТРАНСПОРТ " : "";
        return "\n=========================================\n" +
            special + "Автомобиль с номером " + number +
            ":\n\tВысота: " + height + " мм\n\tМасса: " + weight + " кг";
    }
}